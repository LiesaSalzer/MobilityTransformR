# MobilityTransformationR 0.99

- Function for conversion of migration time to effective mobility in CE-MS.
+ Submitted to Bioconductor
